let cvs = document.querySelector("#flappybird");
let ctx = cvs.getContext("2d");

let bird = document.createElement("img");
bird.src = "images/bird1.png";



let bg = document.createElement("img");
bg.src = "images/bg.png";

let fg = document.createElement("img");
fg.src = "images/fg.png";

let pipeUp = document.createElement("img");
pipeUp.src = "images/pipeUp.png";

let pipeBottom = document.createElement("img");
pipeBottom.src = "images/pipeBottom.png";

let xPos = 50;
let yPos = 250;

let gap = 110;

let pipes_x = [cvs.width, cvs.width + 150];
let pipes_y = [0, -100];

let grav = 0.3
let change = 5;
let score = 0;
let pipespeed = 2;
document.addEventListener("click", function () {
    change = 5;
});


function draw() {
    ctx.clearRect(0, 0, cvs.width, cvs.height);

    if (score >= 10) {
        pipespeed = 4;
    } else {
        pipespeed = 2;
}

    
    ctx.drawImage(bg, 0, 0);

    
    for (let i = 0; i < pipes_x.length; i++) {
        ctx.drawImage(pipeUp, pipes_x[i], pipes_y[i]);
        ctx.drawImage(
            pipeBottom,
            pipes_x[i],
            pipes_y[i] + pipeUp.height + gap
        );

        pipes_x[i] -= pipespeed;

        if (pipes_x[i] === 50) {
            pipes_x.push(pipes_x[pipes_x.length - 1] + 250);
            pipes_y.push(
                Math.floor(Math.random() * pipeUp.height) - pipeUp.height
            );
            score++;
        }
        if(xPos + bird.width >= pipes_x[i] && xPos <= pipes_x[i] + pipeUp.width && (yPos <= pipes_y[i] +
    pipeUp.height || yPos +bird.height >= pipes_y[i] + pipeUp.height + gap) || yPos + bird.height >= cvs.height -
    fg.height) {
                pipes_x = [cvs.width];
                pipes_y = [0];
                score = 0;
                xPos = 50;
                yPos = 250;
                change = 5;
    }
    if (change > 0) {
            bird.src = "images/bird1_up.png";
        } else {
            bird.src = "images/bird1_down.png";
        }
    
}
        
        
        

    yPos = yPos - change;
    change = change - grav;

    
    ctx.drawImage(bird, xPos, yPos);

   
    ctx.drawImage(fg, 0, cvs.height - fg.height);

    ctx.fillStyle = "#000";
    ctx.font = "24px Verdana";
    ctx.fillText("Счет: " + score, 10, cvs.height - 20);


    requestAnimationFrame(draw);
}


draw();


